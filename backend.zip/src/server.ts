import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { Client } from 'pg';

dotenv.config();

const client = new Client({
    host: process.env.POSTGRES_HOST,
    port: Number(process.env.POSTGRES_PORT),
    database: process.env.POSTGRES_DB,
    user: process.env.POSTGRES_USER,
    password: process.env.POSTGRES_PASSWORD
});

client.connect()
    .then(() => console.log('Connected to RDS'))
    .catch(err => console.error('RDS Connection Error:', err));

const app = express();
app.use(express.json());
app.use(cors());

app.get('/', (req, res) => {
    res.send('Backend is running');
});

const port = 8080;
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});

export default app;
